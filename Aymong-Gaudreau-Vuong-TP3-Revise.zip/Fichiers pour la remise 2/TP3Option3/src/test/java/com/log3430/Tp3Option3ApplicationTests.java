package com.log3430;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Tp3Option3Application.class)
public class Tp3Option3ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
